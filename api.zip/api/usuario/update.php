<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$id=$_POST['id'];
$nombre=$_POST['nombre'];
$correo=$_POST['correo'];
$contrasena=$_POST['contrasena'];
$telefono=$_POST['telefono'];
$direccion=$_POST['direccion'];
$identificacion=$_POST['identificacion'];
$idRol=$_POST['idRol'];


$query = "update usuario set nombre = '".$nombre."', correo = '".$correo."', contrasena = '".$contrasena."', telefono = '".$telefono."', direccion = '".$direccion."', identificacion = '".$identificacion."', idRol = '".$idRol."' where idUsuario = '".$id."'";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));

mysqli_close($conn);

?>