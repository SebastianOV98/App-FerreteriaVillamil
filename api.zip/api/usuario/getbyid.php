<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$id=$_POST['id'];

$query = "select * from usuario where idUsuario = '".$id."'";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));

$arr1 = array();
while ($row=mysqli_fetch_array($query_execute)) {
    $arra = array('idUsuario' => $row['idUsuario'],'nombre' => $row['nombre'], 'correo' => $row['correo'], 'contrasena' => $row['contrasena'], 'telefono' => $row['telefono'],
        'direccion' => $row['direccion'], 'identificacion' => $row['identificacion'], 'idRol' => $row['idRol']);
    array_push($arr1, $arra);
    
    echo json_encode(array('usuario' => $arr1));
    

}
mysqli_close($conn);

?>