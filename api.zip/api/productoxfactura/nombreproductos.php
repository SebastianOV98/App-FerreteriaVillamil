<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }


$stmt = $conn->prepare("SELECT idProducto, nombre from producto;");

$stmt->execute();

$stmt->bind_result($idProducto, $nombre);



$productos = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idProducto'] = $idProducto;
        $temp['nombre'] = $nombre;
      
    
        array_push($productos, $temp);
    }


    echo json_encode($productos);


?>

