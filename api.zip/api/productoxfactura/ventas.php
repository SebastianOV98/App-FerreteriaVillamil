<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }




$stmt = $conn->prepare("SELECT idVenta, idUsuario, idPago, fecha FROM venta;");

$stmt->execute();

$stmt->bind_result($idVenta, $idUsuario, $idPago, $fecha);



$venta = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idVenta'] = $idVenta;
        $temp['idUsuario'] = $idUsuario;
        $temp['idPago'] = $idPago;
        $temp['fecha'] = $fecha;

        array_push($venta, $temp);
    }


    echo json_encode($venta);


?>