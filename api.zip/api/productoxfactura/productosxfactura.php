<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }

$idFactura=$_GET['idFactura'];

$stmt = $conn->prepare("SELECT idProducto,idFactura,cantidad,precio from productosxfactura where idFactura = '".$idFactura."';");

$stmt->execute();

$stmt->bind_result($idProducto, $idFactura, $cantidad, $precio);



$productosxfactura = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idProducto'] = $idProducto;
        $temp['idFactura'] = $idFactura;
        $temp['cantidad'] = $cantidad;
        $temp['precio'] = $precio;
    
        array_push($productosxfactura, $temp);
    }


    echo json_encode($productosxfactura);


?>

