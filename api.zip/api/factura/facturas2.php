<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }


$stmt = $conn->prepare("SELECT idFactura,fecha,precioTotal,cantidadTotal,descripcion,idUsuario,idTipoPago from factura;");

$stmt->execute();

$stmt->bind_result($idFactura, $fecha, $precioTotal, $cantidadTotal, $descripcion, $idUsuario, $idTipoPago);



$factura = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idFactura'] = $idFactura;
        $temp['fecha'] = $fecha;
        $temp['precioTotal'] = $precioTotal;
        $temp['cantidadTotal'] = $cantidadTotal;
        $temp['descripcion'] = $descripcion;
        $temp['idUsuario'] = $idUsuario;
        $temp['idTipoPago'] = $idTipoPago;

        array_push($factura, $temp);
    }


    echo json_encode($factura);


?>