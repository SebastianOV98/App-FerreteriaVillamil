<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$fecha=$_POST['fecha'];
$precioTotal=$_POST['precioTotal'];
$cantidadTotal=$_POST['cantidadTotal'];
$descripcion=$_POST['descripcion'];
$idUsuario=$_POST['idUsuario'];
$idTipoPago=$_POST['idTipoPago'];



$query = "insert into factura (idFactura,fecha,precioTotal,cantidadTotal,descripcion,idUsuario,idTipoPago) values (null,'".$fecha."','".$precioTotal."','".$cantidadTotal."','".$descripcion."','".$idUsuario."','".$idTipoPago."')";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));


?>