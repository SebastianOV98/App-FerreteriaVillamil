<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$idUsuario=$_POST['idUsuario'];
$idFactura=$_POST['idFactura'];
$ciudad=$_POST['ciudad'];
$barrio=$_POST['barrio'];
$direccion=$_POST['direccion'];
$latitud=$_POST['latitud'];
$longitud=$_POST['longitud'];
$estado=$_POST['estado'];



$query = "insert into domicilio (idDomicilio,idUsuario,idFactura,ciudad,barrio,direccion,latitud,longitud,estado) values (null,'".$idUsuario."','".$idFactura."','".$ciudad."','".$barrio."','".$direccion."','".$latitud."','".$longitud."','".$estado."')";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));


?>