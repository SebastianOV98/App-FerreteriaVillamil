<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass)
or trigger_error (mysqli_error($conn), E_USER_ERROR);
mysqli_select_db($conn, $db_name);


$id=$_POST['id'];
$nombre=$_POST['nombre'];
$marca=$_POST['marca'];
$descripcion=$_POST['descripcion'];
$precio=$_POST['precio'];
$imagen=$_POST['imagen'];
$idCategoria=$_POST['idCategoria'];
$cantidad=$_POST['cantidad'];


$query = "update producto set nombre = '".$nombre."', marca = '".$marca."', descripcion = '".$descripcion."', precio = '".$precio."', imagen = '".$imagen."', idCategoria = '".$idCategoria."', cantidad = '".$cantidad."' where idProducto= '".$id."'";
//$query = "insert into personas(dni, nombre, telefono, email) values ('1', 'asd', 'asd', 'asd')";
$query_execute = mysqli_query($conn, $query) or die (mysqli_error($conn));

mysqli_close($conn);

?>