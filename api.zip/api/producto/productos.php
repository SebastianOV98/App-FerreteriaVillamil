<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }



$stmt = $conn->prepare("SELECT idProducto, nombre, marca, descripcion, precio, imagen, idCategoria, cantidad FROM producto;");

$stmt->execute();

$stmt->bind_result($idProducto, $nombre, $marca, $descripcion, $precio, $imagen, $idCategoria, $cantidad);



$producto = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idProducto'] = $idProducto;
        $temp['nombre'] = $nombre;
        $temp['marca'] = $marca;
        $temp['descripcion'] = $descripcion;
        $temp['precio'] = $precio;
        $temp['imagen'] = $imagen;
        $temp['idCategoria'] = $idCategoria;
        $temp['cantidad'] = $cantidad;

    
        array_push($producto, $temp);
    }


    echo json_encode($producto);


?>