<?php

$host = "localhost";
$db_name = "ferreteriavillamil";
$username = "root";
$pass = "";
$conn = mysqli_connect($host, $username, $pass, $db_name);

    if(mysqli_connect_errno()){
        die('No fue posible conectarse a la base de datos' . mysqli_connect_error());
    }




$stmt = $conn->prepare("SELECT idCategoria, nombre, imagen FROM categoria;");

$stmt->execute();

$stmt->bind_result($idCategoria, $nombre, $imagen);



$categoria = array();

    while($stmt->fetch()){

        $temp = array();
        $temp['idCategoria'] = $idCategoria;
        $temp['nombre'] = $nombre;
        $temp['imagen'] = $imagen;
    
        array_push($categoria, $temp);
    }


    echo json_encode($categoria);


?>